<?php
header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', true);
ini_set('html_errors', true);

require_once 'sonos2.php';

?>
